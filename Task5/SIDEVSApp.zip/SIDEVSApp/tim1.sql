-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: tim1
-- ------------------------------------------------------
-- Server version	5.7.12-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `faktura`
--

DROP TABLE IF EXISTS `faktura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faktura` (
  `id` bigint(20) NOT NULL,
  `datum_kreiranja` datetime DEFAULT NULL,
  `izlazna_cijena` double NOT NULL,
  `korisnik_id` int(11) DEFAULT NULL,
  `kupac_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKleplt478weyte0y9ddahmij7c` (`korisnik_id`),
  KEY `FKgy3s6hww0wxp7cadppr5w4bp7` (`kupac_id`),
  CONSTRAINT `FKgy3s6hww0wxp7cadppr5w4bp7` FOREIGN KEY (`kupac_id`) REFERENCES `kupac` (`id`),
  CONSTRAINT `FKleplt478weyte0y9ddahmij7c` FOREIGN KEY (`korisnik_id`) REFERENCES `korisnik` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faktura`
--

LOCK TABLES `faktura` WRITE;
/*!40000 ALTER TABLE `faktura` DISABLE KEYS */;
/*!40000 ALTER TABLE `faktura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faktura_lot`
--

DROP TABLE IF EXISTS `faktura_lot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faktura_lot` (
  `id` bigint(20) NOT NULL,
  `cijena` double NOT NULL,
  `kolicina` int(11) NOT NULL,
  `faktura_id` bigint(20) DEFAULT NULL,
  `lot_id` varchar(255) DEFAULT NULL,
  `skladiste_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKntswc1p7u6xkigfaqotubs0xj` (`faktura_id`),
  KEY `FK4sqarswv5q37sw7nr1tv8p8v9` (`lot_id`),
  KEY `FK9x0y9y4d74x6y4mdcbec7k6a5` (`skladiste_id`),
  CONSTRAINT `FK4sqarswv5q37sw7nr1tv8p8v9` FOREIGN KEY (`lot_id`) REFERENCES `lot` (`broj_lota`),
  CONSTRAINT `FK9x0y9y4d74x6y4mdcbec7k6a5` FOREIGN KEY (`skladiste_id`) REFERENCES `skladiste` (`broj_skladista`),
  CONSTRAINT `FKntswc1p7u6xkigfaqotubs0xj` FOREIGN KEY (`faktura_id`) REFERENCES `faktura` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faktura_lot`
--

LOCK TABLES `faktura_lot` WRITE;
/*!40000 ALTER TABLE `faktura_lot` DISABLE KEYS */;
/*!40000 ALTER TABLE `faktura_lot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hibernate_sequence`
--

LOCK TABLES `hibernate_sequence` WRITE;
/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
INSERT INTO `hibernate_sequence` VALUES (3),(3),(3),(3),(3),(3);
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `korisnik`
--

DROP TABLE IF EXISTS `korisnik`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `korisnik` (
  `DTYPE` varchar(31) NOT NULL,
  `id` int(11) NOT NULL,
  `adresa` varchar(255) DEFAULT NULL,
  `datum_polaska_rada` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `ime` varchar(255) DEFAULT NULL,
  `jmbg` varchar(255) DEFAULT NULL,
  `lozinka` tinyblob,
  `prezime` varchar(255) DEFAULT NULL,
  `radno_mjesto` varchar(255) DEFAULT NULL,
  `salt` tinyblob,
  `telefon` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKbsfvsl4e92p9b373j46odivu3` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `korisnik`
--

LOCK TABLES `korisnik` WRITE;
/*!40000 ALTER TABLE `korisnik` DISABLE KEYS */;
INSERT INTO `korisnik` VALUES ('Administrator',1,'Adresa bb','2016-05-22 15:01:13','MAIDAB','MAIDAB','1234567891234','S݂�\0/�E�\njr\�\�\��|!','Korisnicki','radnik','�|�6f\�3S','012353451');
/*!40000 ALTER TABLE `korisnik` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kupac`
--

DROP TABLE IF EXISTS `kupac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kupac` (
  `id` bigint(20) NOT NULL,
  `adresa` varchar(255) DEFAULT NULL,
  `naziv` varchar(255) DEFAULT NULL,
  `obrisan` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_c9x6nrw5urlf7payi42qytp4t` (`naziv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kupac`
--

LOCK TABLES `kupac` WRITE;
/*!40000 ALTER TABLE `kupac` DISABLE KEYS */;
/*!40000 ALTER TABLE `kupac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lijek`
--

DROP TABLE IF EXISTS `lijek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lijek` (
  `id` int(11) NOT NULL,
  `naziv` varchar(255) DEFAULT NULL,
  `proizvodjac` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_4hvt8lfjgejthdeylpuqfruh8` (`naziv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lijek`
--

LOCK TABLES `lijek` WRITE;
/*!40000 ALTER TABLE `lijek` DISABLE KEYS */;
/*!40000 ALTER TABLE `lijek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lot`
--

DROP TABLE IF EXISTS `lot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lot` (
  `broj_lota` varchar(255) NOT NULL,
  `datum_otpisa` datetime DEFAULT NULL,
  `datum_ulaza` datetime DEFAULT NULL,
  `kolicina_tableta` int(11) NOT NULL,
  `rok_trajanja` datetime DEFAULT NULL,
  `tezina` double NOT NULL,
  `ulazna_cijena` double NOT NULL,
  `lijek_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`broj_lota`),
  KEY `FK82aj4ml3by347a0rj4xpwo9pb` (`lijek_id`),
  CONSTRAINT `FK82aj4ml3by347a0rj4xpwo9pb` FOREIGN KEY (`lijek_id`) REFERENCES `lijek` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lot`
--

LOCK TABLES `lot` WRITE;
/*!40000 ALTER TABLE `lot` DISABLE KEYS */;
/*!40000 ALTER TABLE `lot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pakovanje`
--

DROP TABLE IF EXISTS `pakovanje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pakovanje` (
  `id` bigint(20) NOT NULL,
  `datum_nabavke` datetime DEFAULT NULL,
  `kolicina` int(11) NOT NULL,
  `lot_id` varchar(255) DEFAULT NULL,
  `skladiste_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8v2jb8q6xwabrl32eb48qnwft` (`lot_id`),
  KEY `FK9o7oom6oqv1qfq52svdkqedsg` (`skladiste_id`),
  CONSTRAINT `FK8v2jb8q6xwabrl32eb48qnwft` FOREIGN KEY (`lot_id`) REFERENCES `lot` (`broj_lota`),
  CONSTRAINT `FK9o7oom6oqv1qfq52svdkqedsg` FOREIGN KEY (`skladiste_id`) REFERENCES `skladiste` (`broj_skladista`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pakovanje`
--

LOCK TABLES `pakovanje` WRITE;
/*!40000 ALTER TABLE `pakovanje` DISABLE KEYS */;
/*!40000 ALTER TABLE `pakovanje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skladiste`
--

DROP TABLE IF EXISTS `skladiste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skladiste` (
  `broj_skladista` int(11) NOT NULL,
  PRIMARY KEY (`broj_skladista`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skladiste`
--

LOCK TABLES `skladiste` WRITE;
/*!40000 ALTER TABLE `skladiste` DISABLE KEYS */;
INSERT INTO `skladiste` VALUES (1),(2);
/*!40000 ALTER TABLE `skladiste` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-05-22 15:06:24
